INDICE = int(13)
soma = int(0)
k = int(0)

while(k < INDICE):
    
    k = k + 1
    soma = soma + k

print (soma)
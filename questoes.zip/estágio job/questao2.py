def fibonnaci (n):
    if n < 0:
        return None
    if n == 0:
        return []
    if n == 1:
        return [0]
    if n == 2:
        return [0, 1]

    sequencia = [0, 1]
    while sequencia[-1] < n:
        proxNumero = sequencia[-1] + sequencia[-2]
        sequencia.append(proxNumero)
        
    return sequencia[:-1]


def pertenceFibonnaci(n):
    sequencia = fibonnaci(n)
    return n in sequencia


numero = int(input("Digite um número: "))
seqFibonnaci = fibonnaci(numero)

if seqFibonnaci:
    print(f"A sequência de Fibonacci até {numero} é: {seqFibonnaci}")
    
else:
    print(f"O número {numero} é inválido.")

if pertenceFibonnaci(numero):
    print(f"O número {numero} pertence à sequência de Fibonacci.")
    
else:
    print(f"O número {numero} não pertence à sequência de Fibonacci.")
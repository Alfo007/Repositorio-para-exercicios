normal = "Edinaldo"
inverter = ""  

for i in range(len(normal)-1, -1, -1):
    inverter += normal[i]
print(inverter) 
